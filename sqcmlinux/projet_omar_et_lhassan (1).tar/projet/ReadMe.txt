***************
Installation  *
***************
-dezziper le dossier et copier le dossier " projet " sur le dossier personnel
exp: /home/toto

-Deplacer vous dans le repertoire projet

-donner les droits d'execution aux deux scripts en executants la commande:
chmod 777 proj.sh initStat.bash

-pour executer le script script à chaque lancement de console ajouter ce chemin
 sur la derniere ligne du .bashrc:   /home/$USER/projet/script.bash

